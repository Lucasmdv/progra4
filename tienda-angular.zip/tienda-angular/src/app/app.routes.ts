import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { ListPageComponent } from './pages/list-page/list-page.component';
import { DetailsPageComponent } from './pages/details-page/details-page.component';
import { FormPageComponent } from './pages/form-page/form-page.component';
import { EditPageComponent } from './pages/edit-page/edit-page.component';

export const routes: Routes = [
    {path:"home",component:HomeComponent},
    {path:"product/list",component:ListPageComponent},
    {path:"product/:id",component:DetailsPageComponent},
    {path:"product/new",component:FormPageComponent},
    {path:"product/edit",component:EditPageComponent},
    {path:"**",redirectTo: "home"}
];
