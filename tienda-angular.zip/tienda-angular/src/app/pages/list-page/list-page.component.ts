import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from '../../services/product-service.service';
import { Product } from '../../models/Product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-page',
  standalone: true,
  imports: [],
  templateUrl: './list-page.component.html',
  styleUrl: './list-page.component.css'
})
export class ListPageComponent implements OnInit{

  products?: Product[]
  
  constructor(public pService: ProductServiceService, private router: Router){
  }

  ngOnInit(): void {
    this.products = []
    this.getAllProducts()
  }

  getAllProducts(){
    this.pService.getProducts().subscribe({
      next: (data)=> {this.pService.products = data},
      error: (e) => console.log(e)
    })
  }

  editProduct(p : Product){
    this.router.navigate(["/product/edit",p.id])
  }

  deleteProduct(id: string){
    this.pService.deleteProduct(id).subscribe({
      next: (data)=> {console.log(data)},
      error: (e)=> console.log(e)
    })
  }

}
