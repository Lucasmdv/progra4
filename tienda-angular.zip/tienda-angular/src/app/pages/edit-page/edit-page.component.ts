import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-page',
  standalone: true,
  imports: [],
  templateUrl: './edit-page.component.html',
  styleUrl: './edit-page.component.css'
})
export class EditPageComponent {

}
