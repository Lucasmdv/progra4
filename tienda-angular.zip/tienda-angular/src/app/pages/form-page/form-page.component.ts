import { Component } from '@angular/core';

@Component({
  selector: 'app-form-page',
  standalone: true,
  imports: [],
  templateUrl: './form-page.component.html',
  styleUrl: './form-page.component.css'
})
export class FormPageComponent {

}
